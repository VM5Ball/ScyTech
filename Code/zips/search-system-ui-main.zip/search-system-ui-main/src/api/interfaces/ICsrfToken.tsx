export interface ICsrfToken {
    "parameterName": String,
    "token": String,
    "headerName": String,
    "name": String,
    "admin": boolean
}