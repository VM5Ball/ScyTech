import {SearchResponse} from "./SearchResponse";

export interface DocSearchResponse extends SearchResponse {
    title: String
}