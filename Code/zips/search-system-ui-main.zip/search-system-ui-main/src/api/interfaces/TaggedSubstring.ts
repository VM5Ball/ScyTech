export interface TaggedSubstring {
    start: number,
    end: number,
    substring: String
}