export interface PhraseSuggestResponse {
    text: String,
    score: number
}