export enum QueryFlag {
    PHRASE= "PHRASE",
    WORD = "WORD",
    TITLE = "TITLE"
}