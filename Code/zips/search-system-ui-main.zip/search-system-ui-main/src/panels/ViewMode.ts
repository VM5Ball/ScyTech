export const enum ViewMode {
    PAGES = "pages",
    DOC = "docs"
}