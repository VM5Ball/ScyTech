package ru.scytech.documentsearchsystembackend.model;

public enum QueryFlag {
    PHRASE,
    WORD,
    TITLE
}
