package ru.scytech.documentsearchsystembackend;

import org.junit.jupiter.api.Test;
import ru.scytech.documentsearchsystembackend.dao.PageIndexDao;
import ru.scytech.documentsearchsystembackend.model.results.TitleSearchResult;
import ru.scytech.documentsearchsystembackend.services.ElasticRestClient;

import java.io.IOException;


class SearchSystemBackendApplicationTests {

    @Test
    void contextLoads() throws IOException {
    }

}
